import React, { Component } from 'react';

class Logo extends Component {
    render() {
        return (
            <img
                className="mx-auto w-48"
                src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/lotus.webp"
                alt="logo"
            />
        );
    }
}
export default Logo;